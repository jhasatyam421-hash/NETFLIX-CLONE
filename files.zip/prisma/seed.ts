import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main() {
  await prisma.movie.createMany({
    data: [
      {
        title: 'Sample Movie 1',
        overview: 'A sample movie used for the demo.',
        posterUrl: 'https://via.placeholder.com/300x450.png?text=Sample+1',
        hlsUrl: '', // Add HLS manifest URL if you have one
        year: 2022,
        durationMin: 120,
        genres: ['Drama']
      },
      {
        title: 'Sample Movie 2',
        overview: 'Another movie for the demo roster.',
        posterUrl: 'https://via.placeholder.com/300x450.png?text=Sample+2',
        hlsUrl: '',
        year: 2021,
        durationMin: 95,
        genres: ['Action']
      }
    ]
  })
  console.log('Seeded movies.')
}

main()
  .catch(e => { console.error(e); process.exit(1) })
  .finally(async () => { await prisma.$disconnect() })