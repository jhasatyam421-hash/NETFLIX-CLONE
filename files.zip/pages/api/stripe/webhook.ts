import { NextApiRequest, NextApiResponse } from 'next'
import Stripe from 'stripe'
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2024-11-15' })

export const config = { api: { bodyParser: false } }

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  // For demo: verify webhook and process events (checkout.session.completed, invoice.paid, customer.subscription.updated)
  res.status(200).send('ok')
}

export default handler