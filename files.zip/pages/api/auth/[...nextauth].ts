import NextAuth from 'next-auth'
import EmailProvider from 'next-auth/providers/email'
import { PrismaAdapter } from '@next-auth/prisma-adapter'
import prismaPkg from '@prisma/client'
const { PrismaClient } = prismaPkg
const prisma = new PrismaClient()

export default NextAuth({
  adapter: PrismaAdapter(prisma),
  providers: [
    EmailProvider({
      server: process.env.EMAIL_SERVER, // set SMTP in .env
      from: process.env.EMAIL_FROM
    })
  ],
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: 'database' },
  callbacks: {
    async session({ session, user }) {
      // attach user id in session
      (session as any).user.id = user.id
      return session
    }
  }
})