import Link from 'next/link'
import { GetServerSideProps } from 'next'
import prismaPkg from '@prisma/client'
const { PrismaClient } = prismaPkg
const prisma = new PrismaClient()

type Movie = {
  id: string
  title: string
  posterUrl?: string
  overview?: string
}

export default function Home({ movies }: { movies: Movie[] }) {
  return (
    <main className="p-6">
      <h1 className="text-3xl mb-4">Netflix Clone — Home</h1>
      <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-5">
        {movies.map(m => (
          <Link key={m.id} href={`/movies/${m.id}`} className="block">
            <div className="bg-gray-800 rounded overflow-hidden">
              <img src={m.posterUrl || '/placeholder-poster.png'} alt={m.title} className="w-full h-48 object-cover" />
              <div className="p-2">
                <h3 className="text-sm font-semibold">{m.title}</h3>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </main>
  )
}

export const getServerSideProps: GetServerSideProps = async () => {
  const movies = await prisma.movie.findMany({ take: 50, orderBy: { createdAt: 'desc' } })
  return { props: { movies: JSON.parse(JSON.stringify(movies)) } }
}