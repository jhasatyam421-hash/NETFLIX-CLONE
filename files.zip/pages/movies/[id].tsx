import { GetServerSideProps } from 'next'
import prismaPkg from '@prisma/client'
import dynamic from 'next/dynamic'
const ReactPlayer = dynamic(() => import('react-player/lazy'), { ssr: false })
const { PrismaClient } = prismaPkg
const prisma = new PrismaClient()

export default function MoviePage({ movie }: any) {
  return (
    <div className="p-6">
      <h1 className="text-2xl mb-2">{movie.title}</h1>
      <div className="md:flex gap-6">
        <img src={movie.posterUrl || '/placeholder-poster.png'} className="w-48 h-72 object-cover rounded" />
        <div>
          <p className="mb-4">{movie.overview}</p>
          <div style={{ maxWidth: 800 }}>
            {/* HLS simulation - if movie.hlsUrl is set it will play; otherwise a placeholder */}
            {movie.hlsUrl ? (
              <ReactPlayer url={movie.hlsUrl} controls width="100%" />
            ) : (
              <div className="bg-black text-white p-8">No stream available (HLS URL missing)</div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const { id } = ctx.params!
  const movie = await prisma.movie.findUnique({ where: { id: String(id) } })
  if (!movie) return { notFound: true }
  return { props: { movie: JSON.parse(JSON.stringify(movie)) } }
}